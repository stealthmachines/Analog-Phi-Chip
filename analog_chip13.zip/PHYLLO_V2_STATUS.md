# PHYLLO_V2 — Recursive Torus+Phyllotaxis Router: Honest Status

## What was built (this session)

A single generator, `phyllo_v2.py`, that uses **both** repo patterns as the theory
demanded:

- **Phyllotaxis = placement, at every level.** Vogel spiral (θ=n·GA, r=c·√n) places
  the 24 parts inside each cell *and* places the 9 cells (1 reference + 8 strands)
  around the board center. Scales are computed **bottom-up** — component courtyard →
  micro-ring stack → cell disk radius R1 → level-0 spacing C0 = 2·R1+6 — so the same
  code runs at any N by construction. This is the "any-scale contract."

- **Torus = routing chart, per cluster.** Concentric **rings on F.Cu** (the (1,0)
  windings) carry each net; **radial lanes on B.Cu** (the transverse family) connect
  pads to rings; **vias are family switches** at endpoints only. A radial crossing a
  foreign ring is on a different layer → no conflict, which is the whole point of the
  two-family torus decomposition.

- **Inter-level bus corridor.** Level-0 rings (XR/PILOT/PROBE/SUM) live in the annular
  gap between the center disk edge and the first strand disk. Chain nets X_{n+1} ride
  rim bands outside all cells. Verified geometrically to fit (corridor 24.2 < rings
  25.2–27.4 < 30.2 inner edge of nearest strand disk).

- **Planes.** In1=GND, In2=+12V as filled polygons with per-via knockouts (bypasses the
  ZONE_FILLER segfault on dense circular geometry), with a `plane_members` map kept for
  plane-aware LVS.

- **Gate 1 — `audit_clearance.py`.** Independent spatial-hash geometric audit:
  same-layer different-net segment↔segment, via↔track, via↔via, at 0.20 mm.

Board builds cleanly: **208 footprints, ~17,080 segments, 955 vias, 352 mm diameter**
(inside the 400 mm fab limit).

## Where it stands — NOT the contract yet

Gate 1 currently reports **40 clearance violations (13 TT, 27 VT), 34 of them genuine
metal overlaps (gap<0)** — real shorts, not tight-clearance false positives. The board
is therefore **NOT certifiable** and no CLEAN Gerbers were stamped. The gate is doing
its job by refusing.

### Root cause (diagnosed, not guessed)

The unique-angle radial idea is sound and got the count from an initial 19,381 (naive
spiral family) → ~40. The residual is concentrated in two structural spots:

1. **Tap convergence at the inward pole (cell 1 worst).** PILOT/SUM/PROBE tap signals
   all exit toward the same world-center pole. Pole-seeding packed their source pads
   within ~5 mm of each other, so the pad-escape "hop" chords cross at low radius. The
   radially-stacked seeding helped elsewhere but cell 1 (which uniquely has the extra
   PROBE tap = 4 center taps) still crowds.

2. **X-net ring crossings.** Xn is each cell's busy node (6+ pads incl. every tap
   resistor). Its ring is large, and other nets' ring-arrival vias land near where the
   Xn radial passes → the repeating `GND|X`, `X|SUM`, `Xk|kG1` VT violations in nearly
   every cell.

Both are the same underlying issue: the greedy angular allocator (`alloc1`/`alloc_pole`
with `arcsT` occupancy) leaves sub-DA gaps when a cell's angular budget near the pole is
tight. Raising DA starves the allocator (53 violations); lowering it crowds. It
oscillates around 40 rather than converging — a sign the allocator needs a *global*
assignment (interval graph coloring / min-cost matching of lanes to targets), not the
current greedy-with-backtrack.

## Honest verdict

The **architecture** meets the brief: recursive, both patterns, scale-parametric,
plane-aware, with an independent gate. The **router** does not yet produce a 100%-clean
board without intervention — it's ~99.8% clean (40 of ~17k segments) but "close" is not
the contract. The remaining work is a principled global lane assignment for the
pole-convergent taps and the X-net, replacing the greedy allocator. That is a bounded,
well-understood change, not open-ended.

## Files (in gerber_pipeline/)

- `phyllo_v2.py` — the recursive generator (placement + torus router + planes)
- `audit_clearance.py` — Gate 1, independent geometric clearance audit
- `phyllo2_v2_WIP.kicad_pcb` — current board (opens in KiCad 7; 40 flagged nets)

No Gerbers exported: the board is not clean, and stamping Gerbers from an
un-certified board would defeat the purpose of the gate.
