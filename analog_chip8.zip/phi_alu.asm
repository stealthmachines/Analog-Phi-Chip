; ============================================================================
; phi_alu.asm — φ-ONLY SUBSTRATE, PURE INTEGER ALU  (no FPU, no SSE, no libm)
; ----------------------------------------------------------------------------
; The bottom of the stack. φ emerges from the axiom x²=x+1 using only
; add / sub / shl / shr / imul.  No divsd, no fsin, no transcendental hardware.
;
; Fixed-point format: Q32.32  (value = raw / 2^32).  ONE = 1<<32.
;   mulq(a,b) = (a*b) >> 32     via 64x64->128 imul, take high:low, shrd.
;   recip(d)  = 1/d  by Newton:  y <- y*(2 - d*y),  8 iterations, seed 2^(64-bitlen).
;   axiom     = x <- x - (x²-x-1) * recip(2x-1),    8 iterations -> φ.
;
; Build:  nasm -f elf64 phi_alu.asm -o phi_alu.o && ld phi_alu.o -o phi_alu
;         ./phi_alu ; echo $?      -> 161 = floor(φ·100)
; ============================================================================

%define Q      32
%define ONE    0x0000000100000000        ; 1<<32 in Q32.32

section .text
    global _start

; ---- mulq: rax = (rax * rbx) >> 32,  Q32.32 multiply. Clobbers rdx. --------
mulq:
    imul    rbx                          ; rdx:rax = rax * rbx (signed 128)
    shrd    rax, rdx, Q                  ; rax = (rdx:rax) >> 32
    ret

; ---- recip: rax = (1<<32)/rdi in Q32.32, Newton, integer-only --------------
; seed y = 1 << (64 - bitlen(d)) clamped; then y = y*(2 - d*y) x8
recip:
    mov     r8, rdi                      ; r8 = d (the divisor, Q32.32)
    bsr     rcx, r8                      ; rcx = index of highest set bit
    mov     r9, 63
    sub     r9, rcx                      ; r9 = 63 - msb  (approx 2^32/d scale)
    mov     rax, 1
    mov     rcx, r9
    shl     rax, cl                      ; y0 = 1 << (63-msb)   (rough 1/d seed)
    mov     r10, rax                     ; r10 = y
    mov     rcx, 8                       ; 8 Newton iterations
.rloop:
    ; dy = mulq(d, y)
    mov     rax, r8
    mov     rbx, r10
    call    mulq                         ; rax = d*y >> 32
    ; t = 2*ONE - dy   (2.0 in Q32.32 = 2<<32)
    mov     r11, ONE
    lea     rbx, [r11+r11]               ; rbx = 2<<32  (2.0 in Q32.32)
    sub     rbx, rax                     ; rbx = 2 - d*y
    ; y = mulq(y, t)
    mov     rax, r10
    call    mulq                         ; rax = y * (2 - d*y) >> 32
    mov     r10, rax
    loop    .rloop
    mov     rax, r10                     ; return 1/d
    ret

_start:
    ; x = 1.5 in Q32.32  = 3<<31
    mov     r12, 3
    shl     r12, 31                      ; r12 = x
    mov     r13, 8                       ; 8 axiom iterations
.axiom:
    ; f = x*x - x - ONE
    mov     rax, r12
    mov     rbx, r12
    call    mulq                         ; rax = x^2 (Q32.32)
    sub     rax, r12                     ; - x
    mov     r11, ONE
    sub     rax, r11                     ; - 1
    mov     r14, rax                     ; r14 = f  (may be negative)
    ; d = 2x - ONE
    mov     r15, r12
    add     r15, r15                     ; 2x
    mov     r11, ONE
    sub     r15, r11                     ; d = 2x - 1
    ; inv = recip(d)
    mov     rdi, r15
    call    recip                        ; rax = 1/d
    ; delta = mulq(f, inv)   (signed f handled by imul in mulq)
    mov     rbx, rax                     ; rbx = inv
    mov     rax, r14                     ; rax = f
    call    mulq                         ; rax = f/d
    ; x = x - delta
    sub     r12, rax
    dec     r13
    jnz     .axiom

    ; φ now in r12 (Q32.32). exit = floor(φ*100) = (r12 * 100) >> 32
    mov     rax, r12
    mov     rbx, 100
    imul    rbx                          ; rdx:rax = φ_raw * 100
    shrd    rax, rdx, Q                  ; >>32 -> integer 161
    mov     rdi, rax
    mov     rax, 60
    syscall
