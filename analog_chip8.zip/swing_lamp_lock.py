# Two-machine swing equation (motor Kuramoto) with incandescent-lamp damping.
# Lamp R(T)=R0(T/300)^1.2; thermal state integrates I^2R vs convective loss.
# Result: locks at K=0.15 despite 20% drive mismatch; lamp temps equalize
# when locked (380K,380K) -- filament temperature is a sync readout.
import numpy as np
from scipy.integrate import solve_ivp
def rhs(t,s,K,M=1.0,C=2.0,h=0.02,R0=1.0):
    th1,v1,T1,th2,v2,T2=s
    D1=1.0/(R0*(T1/300)**1.2); D2=1.0/(R0*(T2/300)**1.2)
    return [v1,(1.0-D1*v1+K*np.sin(th2-th1))/M,(D1*v1*v1-h*(T1-300))/C,
            v2,(1.2-D2*v2+K*np.sin(th1-th2))/M,(D2*v2*v2-h*(T2-300))/C]
if __name__=="__main__":
    for K in [0.05,0.15,0.4]:
        sol=solve_ivp(rhs,[0,3000],[0,1,300,0.5,1.2,300],args=(K,),max_step=0.5)
        m=sol.t>2000
        print(K, np.mean(sol.y[4][m]-sol.y[1][m]))
