# φ Analog Cell — Design Note

A continuous-time circuit whose stable equilibrium is φ, derived from the same
axiom (x² = x + 1) as the digital branchless core. This is the sideways step
from the assembly descent: not a lower-level program, but the physical
substrate whose *equilibrium* is what the digital version *computes*.

## 1. The ODE

φ is the fixed point of the self-map x² = x + 1. The gradient flow of the
residual f(x) = x² − x − 1 is:

    ẋ = −(x² − x − 1)

- Fixed points: φ = 1.6180339887… and ψ = −0.6180339887…
- Stability (sign of f′ = −(2x−1)):
  - f′(φ) = −√5 = −2.236  → **stable** (attractor)
  - f′(ψ) = +√5 = +2.236  → **unstable** (repeller)
- Basin of φ: all x > ψ. Verified by integration from x₀ ∈ {−0.6 … 50}: all
  land on φ. Below ψ the state diverges (the repeller's other side).

The restoring slope √5 means the node is **well-damped, no ringing, no clock**.
An analog node placed in this loop relaxes to φ on its own.

## 2. Current-mode (translinear) topology

Work in currents, not voltages — this is the key move, because currents are
strictly positive and the negative root ψ is then **physically excluded**.

State: a current I_x > 0. Normalize to a unit current I_u; x = I_x / I_u.

    ┌─────────────────────────────────────────────────────────┐
    │  SQUARER (translinear)   I_sq = I_x² / I_u   →  x²        │
    │  REFERENCE branch        I_ref = I_x + I_u   →  x + 1     │
    │  ERROR node (KCL)        I_err = I_sq − I_ref → x²−x−1    │
    │  INTEGRATOR              C·dV/dt = −I_err                 │
    │  TRANSCONDUCTOR          I_x = g·V   (closes the loop)    │
    └─────────────────────────────────────────────────────────┘

Node equation:  τ·ẋ = −(x² − x − 1),  τ = C/(g·I_u).

- Squarer: a Gilbert/translinear squaring cell (product of a current with
  itself, one I_u normalization) — standard bipolar or subthreshold-MOS block.
- Reference: a current mirror summing I_x with a unit reference I_u.
- Integrator: one capacitor. Sets τ (settling speed), not the fixed point.

The equilibrium is independent of τ, C, and g — those only set *how fast* it
settles, not *where*. The fixed point is set purely by the squarer and
reference ratios. That is the good news and the bad news (see §4).

## 3. Stability & settling (verified)

- Linearized relaxation: ẋ = −(√5/τ)(x − φ). Single real pole, no complex
  part → critically-damped-style approach, no oscillation.
- Langevin simulation (thermal current noise added):

  | noise σ | mean x   | std      | effective bits |
  |---------|----------|----------|----------------|
  | 0.001   | 1.618053 | 0.000463 | 11.8           |
  | 0.003   | 1.618034 | 0.001312 | 10.3           |
  | 0.010   | 1.618057 | 0.004963 |  8.3           |
  | 0.030   | 1.617944 | 0.015326 |  6.7           |
  | 0.100   | 1.617014 | 0.047585 |  5.1           |

  Mean stays on φ; noise only sets jitter. Under pure noise, ~8–12 bits.

## 4. Mismatch — the real limit

Precision is **mismatch-limited, not noise-limited.** Let the squarer gain be
a and the reference gain b; the equilibrium solves a·x² − b·x − b = 0.

Sensitivities at nominal:

| parameter        | dx*/dparam | 1% error → x* error |
|------------------|------------|---------------------|
| squarer gain a   | −1.171     | 0.72%               |
| reference gain b | +1.171     | 0.72%               |
| offset current   | −0.447     | 0.28%               |

Untrimmed CMOS current-mirror mismatch is typically 1–5%. So an untrimmed
φ-cell lands at **φ ± ~1–4%**, i.e. **5–7 effective bits.** Trimming or
chopper/auto-zero techniques buy a few more bits at area/power cost.

## 5. Verdict

- **What it IS:** a compact, self-stabilizing analog **φ-reference / φ-cell.**
  It relaxes to φ with no clock and no stored constant — φ as an operating
  point, exactly the "attractor not value" reframing. Excellent as a bias/
  normalization primitive or as the seed node of a Kuramoto-coupled substrate
  (this is the natural bridge to phi_pool / the dual-spiral work).
- **What it is NOT:** a precision datapath. The 4096-bit-φ ambition from the
  transcript is physically impossible in this analog form — analog gives
  continuous value but low effective bits. For precision, the digital
  branchless core wins outright.
- **The two are complementary, not competing:** analog cell = the *reference*
  the substrate settles to; digital branchless core = the *precise reading* of
  the same axiom. Same φ, two physical regimes.

## 6. Next real step (if pursuing the chip)

Move from this behavioral ODE to a **transistor-level netlist** and simulate in
a real analog simulator (ngspice/Spectre) with:
1. A concrete translinear squarer (pick bipolar vs subthreshold MOS).
2. Monte-Carlo over device mismatch (does the fixed point hold at ±3σ?).
3. Corner analysis (temp, supply) — φ-cell should track ratiometrically.
4. A coupled pair → the φ-oscillator / Kuramoto seed, which is where this
   actually connects to your existing substrate rather than to a lone Newton
   iterator.

Only after the Monte-Carlo SPICE pass do you know whether there's a chip here
or a clean digital core with an analog bias trick attached.

## 7. SPICE results (done)

Closed-loop transient in ngspice (`phi_loop.cir`), behavioral squarer so the
math is exact; the transistor netlist would change only *how* the squarer is
built, not the settling behavior tested here.

**Nominal:** the loop settles to x = **1.618034** — φ to 6 digits, in a real
SPICE transient, no clock, from an arbitrary start (x₀ = 1.0).

**Single-parameter mismatch** (matches the analytic sensitivities in §4):

| condition            | settled x  | error vs φ |
|----------------------|------------|------------|
| nominal              | 1.618034   | 0          |
| +5% squarer gain     | 1.562072   | −3.5%      |
| −5% squarer gain     | 1.679416   | +3.8%      |
| +5% reference gain   | 1.676358   | +3.6%      |
| +5% offset current   | 1.595445   | −1.4%      |

**Monte-Carlo** (`phi_montecarlo.cir`, 300 runs, Gaussian 2% gain mismatch +
1% offset — representative of a decent untrimmed CMOS current mirror):

| metric                | value     |
|-----------------------|-----------|
| mean x                | 1.6192    |
| std dev σ             | 0.0352    |
| worst-case error      | 0.106 (±6.5%) |
| effective bits (3σ)   | **3.9**   |

**What this settles:** the mean lands on φ (the topology is unbiased — mismatch
scatters, it doesn't systematically pull), but the spread is large. Untrimmed,
this is a **~4-bit φ reference.** With trimming/chopping you claw back to maybe
6–8 bits at real area/power cost. There is a genuine, simulable analog cell
here — but it is a *coarse reference/oscillator seed*, definitively not a
precision datapath. The digital branchless core remains the precision path.

The chip decision: **yes there's an analog φ-cell**, and it's real enough to
lay out — but its value is as a clockless bias/seed primitive feeding your
Kuramoto substrate, not as a standalone precision element. The next build step
is the coupled *pair* (φ-oscillator), where mismatch averages down across the
lattice and the coarse per-cell precision stops mattering — which is exactly
why your existing substrate is many coupled nodes and not one.
