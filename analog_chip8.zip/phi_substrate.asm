; ============================================================================
; phi_substrate.asm  —  φ-ONLY SELF-CONSISTENT SUBSTRATE  (SSE2, no libm)
; ----------------------------------------------------------------------------
; NO libm • NO fsin • NO hardcoded φ • NO sin(Ω) • NO time index
;
; LAYER 0 (φ axiom): φ is the unique non-divergent fixed point of the substrate
;   under self-application. Newton on f(x)=x²-x-1, f'(x)=2x-1:
;       x <- x - (x²-x-1)/(2x-1)      -> quadratic convergence to φ.
;   φ is NOT stored as a constant; it is READ OFF the axiom x²=x+1.
;
; LAYER 6 (basin): DT=φ⁻¹ , R=GRID·φ⁻² , A_MAX=3·φ⁴  — all emergent from φ.
; LAYER 1 (fib)  : F(n+1)/F(n) -> φ, the axiom iterated in ℕ (integer regs).
;
; Build:
;   nasm -f elf64 phi_substrate.asm -o phi_substrate.o
;   ld    phi_substrate.o -o phi_substrate
;   ./phi_substrate ; echo $?     -> 161 = floor(φ·100)  (proof φ emerged)
; ============================================================================

section .data
    one       dq 1.0
    two       dq 2.0
    three     dq 3.0
    seed      dq 1.5             ; any x>0.5 converges; NOT φ
    eps       dq 1.0e-15
    grid      dq 64.0
    hundred   dq 100.0
    absmask   dq 0x7FFFFFFFFFFFFFFF

section .bss
    phi       resq 1            ; EMERGENT
    phi_inv   resq 1            ; φ⁻¹ = φ-1
    dt_v      resq 1            ; DT = φ⁻¹
    r_basin   resq 1            ; R  = GRID·φ⁻²
    a_max     resq 1            ; 3·φ⁴
    fib_a     resq 1
    fib_b     resq 1

section .text
    global _start

; ---- LAYER 0: φ emerges via Newton on x²-x-1 (SSE2 scalar) ------------------
_start:
    movsd   xmm0, [seed]                ; xmm0 = x
.axiom:
    movsd   xmm1, xmm0                  ; x
    mulsd   xmm1, xmm0                  ; x²
    subsd   xmm1, xmm0                  ; x²-x
    subsd   xmm1, [one]                 ; f = x²-x-1
    movsd   xmm2, xmm0                  ; x
    addsd   xmm2, xmm2                  ; 2x
    subsd   xmm2, [one]                 ; d = 2x-1
    divsd   xmm1, xmm2                  ; delta = f/d
    movsd   xmm3, xmm0                  ; save old x
    subsd   xmm0, xmm1                  ; x_new = x - delta
    ; |x_new - old| < eps ?
    movsd   xmm4, xmm0
    subsd   xmm4, xmm3
    movsd   xmm5, [absmask]
    andpd   xmm4, xmm5                  ; |Δ| (reg form, no align req)
    ucomisd xmm4, [eps]
    jae     .axiom                      ; not converged -> iterate
    movsd   [phi], xmm0                 ; φ EMERGENT, fixed forever

; ---- LAYER 0 restated: φ⁻¹ = φ-1 ; DT = φ⁻¹ --------------------------------
    movsd   xmm1, [one]
    divsd   xmm1, xmm0                  ; 1/φ
    movsd   [phi_inv], xmm1
    movsd   [dt_v], xmm1

; ---- LAYER 6: A_MAX = 3·φ⁴ -------------------------------------------------
    movsd   xmm2, xmm0
    mulsd   xmm2, xmm2                  ; φ²
    mulsd   xmm2, xmm2                  ; φ⁴
    mulsd   xmm2, [three]              ; 3φ⁴
    movsd   [a_max], xmm2

; ---- LAYER 6: R = GRID · φ⁻² -----------------------------------------------
    movsd   xmm3, xmm1                  ; 1/φ
    mulsd   xmm3, xmm1                  ; φ⁻²
    mulsd   xmm3, [grid]               ; GRID·φ⁻²
    movsd   [r_basin], xmm3

; ---- LAYER 1: Fibonacci = axiom iterated in ℕ ------------------------------
    mov     qword [fib_a], 1
    mov     qword [fib_b], 1
    mov     rcx, 90
.fib:
    mov     rax, [fib_a]
    add     rax, [fib_b]
    mov     rdx, [fib_b]
    mov     [fib_a], rdx
    mov     [fib_b], rax
    loop    .fib

; ---- EXIT: floor(φ·100) = 161 proves φ emerged -----------------------------
    movsd   xmm0, [phi]
    mulsd   xmm0, [hundred]
    cvttsd2si rdi, xmm0                 ; floor via truncation -> 161
    mov     rax, 60
    syscall
