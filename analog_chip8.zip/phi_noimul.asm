; ============================================================================
; phi_noimul.asm — φ SUBSTRATE ON A MULTIPLIER-FREE ALU
; ----------------------------------------------------------------------------
; NO imul • NO mul • NO div • NO FPU • NO SSE • NO libm • NO φ constant.
; Only: add, sub, shl, shr, and, cmp/test, branches, mov.
;
; φ emerges from the axiom x²=x+1. Multiplication is shift-and-add; division
; (reciprocal) is Newton over that shift-add multiply. φ is the fixed point.
;
; Q32.32 fixed point. ONE=1<<32. Values are signed 64-bit read as raw/2^32.
;
; Build: nasm -f elf64 phi_noimul.asm -o phi_noimul.o && ld phi_noimul.o -o phi_noimul
;        ./phi_noimul ; echo $?     -> 161 = floor(φ·100)
; ============================================================================

%define Q 32

section .text
    global _start

; ----------------------------------------------------------------------------
; umul: unsigned 64x64 -> 128 product via shift-add.  NO hardware multiply.
;   in:  rax = a, rbx = b
;   out: rdx:rax = 128-bit product  (rdx = high, rax = low)
;   clobbers: rcx, rsi, rdi, r8
; Algorithm: for each set bit i of b, add (a << i) into the 128-bit accumulator.
; ----------------------------------------------------------------------------
umul:
    mov     rsi, rax                     ; rsi = a (multiplicand, low part)
    xor     rdi, rdi                     ; rdi = a_high (shifts spill up here)
    xor     r8,  r8                      ; r8  = acc_high
    xor     rax, rax                     ; rax = acc_low  (result low)
    mov     rcx, 64                      ; 64 bit positions
.umul_bit:
    test    rbx, 1                       ; low bit of remaining b set?
    jz      .umul_skip
    add     rax, rsi                     ; acc_low  += a_low
    adc     r8,  rdi                     ; acc_high += a_high + carry
.umul_skip:
    ; a <<= 1  (128-bit shift of rdi:rsi)
    shl     rsi, 1
    rcl     rdi, 1                       ; carry from rsi into rdi
    ; b >>= 1
    shr     rbx, 1
    dec     rcx
    jnz     .umul_bit
    mov     rdx, r8                      ; rdx = acc_high
    ret

; ----------------------------------------------------------------------------
; mulq: signed Q32.32 multiply -> (a*b) >> 32.
;   in:  rax = a, rbx = b   (signed)
;   out: rax = result (signed Q32.32)
;   Uses umul on magnitudes, then sign-corrects. Clobbers rcx,rdx,rsi,rdi,r8,r9.
; ----------------------------------------------------------------------------
mulq:
    push    rbp                          ; preserve caller's y (recip uses rbp)
    xor     r9, r9                       ; r9 = sign flag (0 = positive)
    ; abs(a)
    test    rax, rax
    jns     .a_pos
    neg     rax
    xor     r9, 1
.a_pos:
    ; abs(b)
    test    rbx, rbx
    jns     .b_pos
    neg     rbx
    xor     r9, 1
.b_pos:
    call    umul                         ; rdx:rax = |a|*|b|
    ; shift right by Q=32: result = (rdx:rax) >> 32
    shrd    rax, rdx, Q                  ; rax = low 64 of the 128 >>32
    ; apply sign
    test    r9, r9
    jz      .done
    neg     rax
.done:
    pop     rbp
    ret

_start:
    ; x = 1.5 in Q32.32 = 3<<31
    mov     r12, 3
    shl     r12, 31
    mov     r13, 8                       ; axiom iterations
.axiom:
    ; f = x*x - x - ONE
    mov     rax, r12
    mov     rbx, r12
    call    mulq                         ; x^2
    sub     rax, r12                     ; - x
    mov     r11, 1
    shl     r11, Q                       ; r11 = ONE = 1<<32
    sub     rax, r11                     ; - 1
    mov     r14, rax                     ; f
    ; d = 2x - ONE
    mov     r15, r12
    add     r15, r15                     ; 2x
    sub     r15, r11                     ; - ONE
    ; inv = recip(d)  (Newton, uses mulq)
    mov     rdi, r15
    call    recip                        ; rax = 1/d (Q32.32)
    ; delta = f * inv
    mov     rbx, rax
    mov     rax, r14
    call    mulq                         ; f/d
    sub     r12, rax                     ; x -= delta
    dec     r13
    jnz     .axiom

    ; exit code = floor(φ*100) = (r12 * 100) >> 32   via shift-add mulq path
    mov     rax, r12
    mov     rbx, 100
    ; abs not needed (both positive); do umul + >>32
    call    umul
    shrd    rax, rdx, Q
    mov     rdi, rax                     ; 161
    mov     rax, 60
    syscall

; ----------------------------------------------------------------------------
; recip: rax = ONE/rdi (Q32.32) via Newton y <- y*(2 - d*y). Uses mulq only.
;   in: rdi = d (Q32.32, positive)
;   out: rax = 1/d
;   clobbers many; preserves nothing but returns in rax.
; ----------------------------------------------------------------------------
recip:
    mov     r10, rdi                     ; r10 = d
    bsr     rcx, r10                      ; msb index
    mov     r9, 63
    sub     r9, rcx                       ; 63 - msb
    mov     rax, 1
    mov     rcx, r9
    shl     rax, cl                       ; y0 = 1 << (63-msb)
    mov     rbp, rax                      ; rbp = y  (callee-saved, survives calls)
    ; --- use a stack counter to avoid clobbering caller's r13 ---
    push    qword 8
.rl:
    ; dy = mulq(d, y)
    mov     rax, r10
    mov     rbx, rbp
    call    mulq
    ; t = 2*ONE - dy
    mov     r11, 1
    shl     r11, Q
    add     r11, r11                      ; 2*ONE
    sub     r11, rax                      ; t
    ; y = mulq(y, t)
    mov     rax, rbp
    mov     rbx, r11
    call    mulq
    mov     rbp, rax
    ; decrement stack counter
    dec     qword [rsp]
    jnz     .rl
    add     rsp, 8
    mov     rax, rbp
    ret
