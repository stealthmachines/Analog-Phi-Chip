# Analysis for the Kuramoto tile decks (tile4_free, tile4_lock, tile_phi).
# Interpolated zero-crossing frequency per node + FFT mode readout of the sum.
import numpy as np
phi=(1+5**0.5)/2
def load(f):
    d=np.loadtxt(f); return d[:,0],[d[:,i] for i in range(1,d.shape[1],2)]
def freq(t,x,t0=4e-4):
    m=t>t0; tt=t[m]; xx=x[m]-x[m].mean()
    i=np.where((xx[:-1]<0)&(xx[1:]>=0))[0]
    tc=tt[i]-xx[i]*(tt[i+1]-tt[i])/(xx[i+1]-xx[i])
    return (len(tc)-1)/(tc[-1]-tc[0])
if __name__=="__main__":
    for f in ["tile4_free.txt","tile4_lock.txt","tile_phi.txt"]:
        try:
            t,vs=load(f); print(f, [f"{freq(t,v)/1e3:.3f}kHz" for v in vs])
        except OSError: pass
