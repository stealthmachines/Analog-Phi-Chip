; ============================================================================
; phi_branchless.asm — φ AS A DATAFLOW CIRCUIT
; ----------------------------------------------------------------------------
; NO imul/mul • NO div • NO FPU/SSE • NO libm • NO φ constant •
; NO data-dependent branches inside the arithmetic (masked add, not test+jump).
;
; The inner multiply is straight-line: each bit contributes  acc += (a & mask)
; where mask = 0-bit  (all-ones if bit set, zero if clear). No control
; divergence on data — the only remaining jumps are fixed-count loop closers
; (constant trip count) and the sign fixups, which are themselves branchless
; via cmov / mask. φ = fixed point of x²=x+1 over this circuit.
;
; Q32.32 fixed point. ONE=1<<32.
; Build: nasm -f elf64 phi_branchless.asm -o o.o && ld o.o -o phi_branchless
;        ./phi_branchless ; echo $?   -> 161 = floor(φ·100)
; ============================================================================

%define Q 32

section .text
    global _start

; ----------------------------------------------------------------------------
; umul: unsigned 64x64->128 shift-add, BRANCHLESS inner body.
;   in:  rax=a, rbx=b     out: rdx:rax = product
;   regs: rsi:rdi = shifted multiplicand (lo:hi), r8=acc_lo, r9=acc_hi,
;         r10=mask, r11=tmp, rcx=fixed counter (64, data-independent)
; ----------------------------------------------------------------------------
umul:
    mov     rsi, rax                     ; multiplicand low
    xor     rdi, rdi                     ; multiplicand high
    xor     r8,  r8                      ; acc low
    xor     r9,  r9                      ; acc high
    mov     rcx, 64                      ; CONSTANT trip count (no data branch)
.ub:
    ; mask = 0 - (b & 1)   -> all-ones if lsb set, else 0    (branchless select)
    mov     r10, rbx
    and     r10, 1
    neg     r10                          ; r10 = 0x000..0 or 0xFFF..F
    ; add (multiplicand & mask) into acc  (128-bit)
    mov     r11, rsi
    and     r11, r10                     ; add_lo
    add     r8, r11
    mov     r11, rdi
    and     r11, r10                     ; add_hi
    adc     r9, r11                      ; + carry from acc_lo add
    ; multiplicand <<= 1  (128-bit)
    shl     rsi, 1
    rcl     rdi, 1
    ; b >>= 1
    shr     rbx, 1
    dec     rcx
    jnz     .ub                          ; fixed 64 iterations — count, not data
    mov     rax, r8
    mov     rdx, r9
    ret

; ----------------------------------------------------------------------------
; mulq: signed Q32.32 multiply, branchless sign handling via cmov.
;   in: rax=a, rbx=b   out: rax=(a*b)>>32 signed.  Preserves rbp.
; ----------------------------------------------------------------------------
mulq:
    push    rbp
    ; sign = sign(a) XOR sign(b), captured in r12b-free way using r15
    mov     r15, rax
    xor     r15, rbx                     ; sign bit of r15 (bit63) = result sign
    shr     r15, 63                      ; r15 = 0 or 1  (result negative?)
    ; abs(a) branchless:  t = a>>63 (0 or -1); a = (a XOR t) - t
    mov     r11, rax
    sar     r11, 63
    xor     rax, r11
    sub     rax, r11                     ; rax = |a|
    ; abs(b)
    mov     r11, rbx
    sar     r11, 63
    xor     rbx, r11
    sub     rbx, r11                     ; rbx = |b|
    call    umul                         ; rdx:rax = |a|*|b|
    shrd    rax, rdx, Q                  ; >>32
    ; conditionally negate: neg_val = -rax; select via cmov on r15
    mov     r11, rax
    neg     r11                          ; r11 = -result
    test    r15, r15
    cmovnz  rax, r11                     ; if sign set, take negated (branchless select)
    pop     rbp
    ret

_start:
    mov     r12, 3
    shl     r12, 31                      ; x = 1.5 (Q32.32)
    mov     r13, 8                       ; axiom iters (fixed)
.axiom:
    mov     rax, r12
    mov     rbx, r12
    call    mulq                         ; x^2
    sub     rax, r12                     ; -x
    mov     r11, 1
    shl     r11, Q                       ; ONE
    sub     rax, r11                     ; f = x^2-x-1
    mov     r14, rax
    mov     r15, r12
    add     r15, r15
    sub     r15, r11                     ; d = 2x-1
    mov     rdi, r15
    call    recip
    mov     rbx, rax
    mov     rax, r14
    call    mulq                         ; delta = f/d
    sub     r12, rax                     ; x -= delta
    dec     r13
    jnz     .axiom

    ; exit = floor(φ*100) = (r12*100)>>32
    mov     rax, r12
    mov     rbx, 100
    call    umul
    shrd    rax, rdx, Q
    mov     rdi, rax
    mov     rax, 60
    syscall

; ----------------------------------------------------------------------------
; recip: ONE/rdi via Newton over mulq (branchless multiply underneath).
;   in: rdi=d>0   out: rax=1/d.  y kept in rbp across mulq calls.
; ----------------------------------------------------------------------------
recip:
    mov     r10, rdi
    bsr     rcx, r10                      ; msb (loop count fixed after this)
    mov     r9, 63
    sub     r9, rcx
    mov     rax, 1
    mov     rcx, r9
    shl     rax, cl                       ; seed y
    mov     rbp, rax
    push    qword 8
.rl:
    mov     rax, r10
    mov     rbx, rbp
    call    mulq                          ; d*y
    mov     r11, 1
    shl     r11, Q
    add     r11, r11                       ; 2*ONE
    sub     r11, rax                       ; 2 - d*y
    mov     rax, rbp
    mov     rbx, r11
    call    mulq                          ; y*(2-d*y)
    mov     rbp, rax
    dec     qword [rsp]
    jnz     .rl
    add     rsp, 8
    mov     rax, rbp
    ret
