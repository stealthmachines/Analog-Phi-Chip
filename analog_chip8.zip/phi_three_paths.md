# φ Substrate — Three Design Paths

Same math layer, three physical media. Kuramoto here means the phase-coupling
dynamics dθᵢ/dt = ωᵢ + K·Σ sin(θⱼ−θᵢ) — Spiral 2 of the base-4 map, the
endogenous drive. The lattice operator 𝓛ₙ(z) is the *amplitude* operator
describing the modes of the field those oscillators produce. The paths below
implement the Kuramoto layer; 𝓛ₙ is what you read off the settled array in
any of them.

**One theorem powers all three paths — Hurwitz:** |φ − p/q| > 1/(√5·q²), and
φ is the extremal (worst-approximable) number. Two faces of it:
- *Lock resistance:* φ-ratio oscillators need maximal coupling before any
  low-order rational captures them → modes stay distinct under coupling.
- *Convergent precision:* φ's best rational approximations are exactly the
  Fibonacci ratios F(n+1):F(n) → integer mechanisms hit φ optimally.

---

## Path 1 — Silicon (continuance of the primitive set)

Status: P1–P8 SPICE-validated (see `phi_chip_primitives.md`). Translinear
squarer, all-transistor φ-cell (current-domain invariance: φ lives in the
current, not the voltage), √N mismatch averaging (verified N=2, N=4), and the
two-cell oscillator (f = k/2πC, measured 47.5 vs predicted 47.7 kHz;
oscillation threshold g > √5 — the axiom's own derivative sets the
oscillation condition).

Next step: N-oscillator Kuramoto tile. Strengths: integration (thousands of
nodes), the exact translinear x²=x+1 loop, tapeout track. Weakness: per-cell
precision ~4 bits untrimmed; precision comes from the lattice (√N) or from
the digital branchless core alongside.

## Path 2 — Vacuum tubes

**This physics was discovered in tubes.** Van der Pol's oscillator (1926) IS
a triode circuit; injection locking (Adler 1946) IS the single-oscillator
Kuramoto equation; van der Pol & van der Mark's 1927 neon/triode experiments
observed the devil's staircase. Tubes are the native medium of the Kuramoto
layer.

**Verified (van der Pol pair, velocity coupling, relaxation regime µ=2):**

| coupling ε | 3:2-detuned pair | φ-detuned pair |
|------------|------------------|----------------|
| 0.4        | free (pulled)    | free (pulled)  |
| 0.5        | **CAPTURED**     | free           |
| 0.6        | captured         | **captured (last)** |

The φ-ratio pair is the last to lose its independent frequency — Hurwitz in
action. Design consequence: a tube array with φ-ratio tank frequencies
maximally resists spurious sync and preserves mode distinctness; coupling
strength becomes a clean global knob from "independent" to "locked."

Architecture: each node = one triode LC oscillator (van der Pol by nature);
coupling = resistive/capacitive injection (Adler); amplitude regulation =
the tube's own saturation. The x²=x+1 *amplitude* identity has no translinear
shortcut in tubes (3/2-power law, not exponential) — quadratics need
quarter-square diode networks (the Philbrick way) — so the tube path is the
**phase/Kuramoto substrate**, not the amplitude-φ reference. Tube drift is
irrelevant by design: sync tolerates drift; that is what sync is for.

Scale: ~10–100 nodes on a bench. The fastest route to a *physical* φ-Kuramoto
machine you can touch.

## Path 3 — Motors + incandescent lamps

The swing equation of coupled machines M·θ̈ = P − D·θ̇ + K·sin(Δθ) IS
second-order Kuramoto (power grids are the canonical instance). The
incandescent lamp is the classic adaptive damper — R(T) rises with filament
temperature (the HP200A amplitude-stabilization trick), giving slow thermal
self-regulation.

**Verified (two-machine swing + lamp thermal model):**
- 20% drive-power mismatch: locks at K = 0.15.
- When locked, the two lamp temperatures **equalize** (380 K, 380 K vs
  363/402 K unlocked) — filament temperature is a direct physical readout of
  synchronization. The sync order parameter is visible as light.

**The gear result — mechanical φ beats the silicon lattice on precision:**

| gear pair (teeth) | ratio       | error vs φ |
|-------------------|-------------|-----------|
| 21:13             | 1.61538462  | 1.6e-3    |
| 55:34             | 1.61764706  | 2.4e-4    |
| 233:144           | 1.61805556  | 1.3e-5    |
| 610:377           | 1.61803714  | **1.9e-6** |

Fibonacci convergents are Hurwitz-optimal, and integers are exact: a 610:377
gear pair holds φ to 2 ppm — the analog silicon lattice needs ~5,900 cells
for 1,000 ppm. Mechanical φ is *cheap* because ℕ is exact and Fibonacci is
the axiom iterated in ℕ (LAYER 1, literally).

Scale: a handful of nodes, room-sized, slow (Hz), pedagogically unbeatable:
sync you can see (lamps) and φ you can mesh (gears).

---

## Comparison

| aspect              | silicon           | tubes              | motors+lamps       |
|---------------------|-------------------|--------------------|--------------------|
| Kuramoto nodes      | 10³–10⁶           | 10¹–10²            | 10⁰–10¹            |
| amplitude φ (x²=x+1)| exact (translinear)| hard (no exp law) | via gears (exact ℕ)|
| φ precision         | √N lattice, ~10 bit @ 6k cells | n/a (phase medium) | 2 ppm @ 610:377 teeth |
| lock-resistance use | φ-ratio bias plan | **native** (verified) | swing-eq (verified) |
| readout             | currents          | RF/audio           | **light** (lamp temp) |
| speed               | MHz–GHz           | kHz–MHz            | Hz                 |
| track               | tapeout           | bench demonstrator | exhibit/teaching   |

The three paths split the axiom's two identities cleanly: **silicon and gears
carry the amplitude identity x²=x+1** (translinear loop; Fibonacci teeth);
**tubes and swing machines carry the phase identity** (φ as the most
irrational winding number — maximal desynchronization capacity). A full
substrate needs both — which is exactly the two-spiral structure of LAYER 2:
one exogenous amplitude drive, one endogenous phase drive.

## Files

- `vdp_golden_lock.py` — tube-physics capture experiment (Hurwitz verified)
- `swing_lamp_lock.py` — motor+lamp sync with thermal readout
- `phi_chip_primitives.md` — silicon path P1–P8
- Honest note: an earlier circle-map plateau numeric was inconclusive
  (estimator noise + tongue bending); the van der Pol capture experiment is
  the clean evidence, and Hurwitz's theorem is the guarantee.
