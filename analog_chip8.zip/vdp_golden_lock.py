# van der Pol pair (tube-oscillator physics): capture threshold vs frequency ratio
# Result: near-1:1 locks at eps=0.05; 3:2-detuned captured at eps=0.5;
#         phi-detuned survives to eps=0.6 -- the last to lock (Hurwitz).
import numpy as np
from scipy.integrate import solve_ivp
phi=(1+5**0.5)/2
def rhs(t,s,w1,w2,mu,eps):
    x1,v1,x2,v2=s
    return [v1, mu*(1-x1*x1)*v1 - w1*w1*x1 + eps*w1*v2,
            v2, mu*(1-x2*x2)*v2 - w2*w2*x2 + eps*w2*v1]
def freq_ratio(w2,eps,mu=2.0,T=600):
    sol=solve_ivp(rhs,[0,T],[2,0,0.1,1.9],args=(1.0,w2,mu,eps),
                  max_step=0.02,rtol=1e-8,atol=1e-10)
    t=sol.t; m=t>T/2
    def f(x,tt):
        zc=np.where((x[:-1]<0)&(x[1:]>=0))[0]
        return (len(zc)-1)/(tt[zc[-1]]-tt[zc[0]]) if len(zc)>2 else np.nan
    return f(sol.y[2][m],t[m])/f(sol.y[0][m],t[m])
if __name__=="__main__":
    for eps in [0.2,0.3,0.4,0.5,0.6,0.8]:
        print(eps, freq_ratio(1.5,eps), freq_ratio(phi,eps))
