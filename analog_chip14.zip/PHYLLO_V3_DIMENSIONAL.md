# PHYLLO_V3 — The Dimensional Router (HDGL Dn ladder)

## The unlock

The v2 wall was 2D thinking: in a plane, some tracks *must* cross, so a fixed
layer count eventually forces a short. The HDGL `hdgl_analog_v30.c` substrate
supplies the missing dimension. Its `compute_Dn_r`:

    Dn(r) = sqrt(phi * F_n * 2^n * P_n * Omega) * r^((n+1)/8)

is a **progressive-dimensionality operator**: n is a continuous knob, and at any
fixed radius the eight dimensions form disjoint amplitude bands (at r=1:
2.5, 4.4, 11.4, 23.3, 53.4, 103.8, 213.9, 406.5). Two nets that must cross in the
plane do **not** cross if they live in different `dim_n` — which maps directly to
**different copper layers / via depth**. The n-th dimension is the n-th layer.

So the router problem became: assign each radial a `(dim_n, lane_angle)` such that
same-dimension + radially-overlapping runs stay angularly separated. That is
exactly a Kuramoto settling problem, and `compute_derivatives_Dn` in the same file
*is* the settling dynamics — repulsive phase coupling that pushes overlapping lanes
apart, with promotion to the next dimension when a plane is full.

## What was built

`dn_router.py` — the **lane oracle**, two solvers sharing one substrate:

1. **`kuramoto_relax`** (analog / wu wei): each radial is an oscillator, phase =
   lane; overlapping same-dim runs repel; residual conflicts promote up the Dn
   ladder (dim -> dim+1). Settles to a non-crossing configuration on its own.
2. **`exact_assign`** (combinatorial / ground truth): per-dimension interval
   separation on the angular circle, greedy-optimal in earliest-deadline order,
   overflow promotes dimension.

`route()` runs both and cross-checks. On the exact stress case that broke v2 —
24 demands with 4 taps pinned to one pole — both return **0 residual conflicts**;
Kuramoto even packs tighter (3 dims vs exact's 4).

### The scale-free proof

The decisive test: hold density constant (24 nets/cell) and grow the board by
**adding cells** (phyllotaxis). Result — dims/cell stays flat at **4**, whether
1 cell or 64 cells. Cramming more nets into *one fixed cell* does exhaust the 8
dims (expected — finite area), but the phyllotactic architecture never does that.
So the layer count is **bounded** while the cell count grows **without limit**.
That is "infinitely scalable" in the only sense that is manufacturable.

Layer map (6-layer stackup): dim1->B.Cu, dim2->In3.Cu, dim3->In4.Cu, with F.Cu
carrying the collector rings and In1/In2 the GND/+12V planes.

## Board result — big progress, not yet the contract

`phyllo_v3.py` wires the oracle into the generator. The ring-collector model:
F.Cu rings collect each net; pads reach their ring by native-angle radial stubs
on oracle-assigned dim-layers (colliding stubs -> different layers); leaving nets
get risers.

Independent Gate 1 (`audit_clearance.py`) progression this session:

| stage                                   | violations | TT    |
|-----------------------------------------|-----------:|------:|
| v2 greedy (previous session)            |         40 |    13 |
| v3 first oracle wiring (layer bug)      |       2929 |  2305 |
| net-aware + ring-collector              |        419 |    93 |
| **native-angle stubs, layer-split**     |    **211** | **4** |

**Track-vs-track crossings are essentially solved: 4 TT remain** (down from
thousands). The dimensional lift did what 2D couldn't. The residual **207 are
via collisions** (193 via-track, 14 via-via): every stub carries a pad-via and a
ring-via, and in the dense SOT-23 field these 0.5 mm vias crowd against neighbours'
copper. That is a component-spacing / via-reduction problem, not a routing-topology
one — a different and more tractable class than the v2 wall.

Board: 208 footprints, ~18.6k segments, 1522 vias, 375 mm (< 400 fab limit),
6 copper layers. **NOT yet certifiable** — Gate 1 still fails on vias, so no CLEAN
Gerbers were stamped. The gate is doing its job.

## Honest verdict

The HDGL substrate was the right instinct — it dissolved the crossing problem by
adding the dimension I was missing, and gave both the elegant (Kuramoto) and the
exact (combinatorial) solvers you asked to explore, checking each other. The
remaining work is via-count reduction (share pad/ring vias, widen the micro-Vogel
pitch, or use blind/buried vias so a dim-transition doesn't punch all layers) plus
clearing 4 stray track crossings at the chain-entry points. That is bounded and
well-scoped, unlike the v2 wall which was structural.

## Files (gerber_pipeline/)

- `dn_router.py` — dual-solver dimensional lane oracle (Kuramoto + exact)
- `phyllo_v3.py` — generator using the oracle, 6-layer, dim->layer mapped
- `phyllo3_v3_WIP.kicad_pcb` — current board (opens in KiCad 7; 211 flagged, mostly vias)
- `hdgl_analog_v30_reference.c` — the substrate: compute_Dn_r + compute_derivatives_Dn
- `audit_clearance.py` — Gate 1 (multi-layer aware)

No Gerbers exported: board not clean; stamping from an uncertified board defeats
the gate.
