# φ Analog Chip — Validated Primitive Set

Every primitive below is SPICE-validated (ngspice, transistor level unless
noted). Netlists included. Measured numbers are from actual simulation runs,
not estimates.

---

## P1 — Translinear squarer  (`phi_squarer_translinear.cir`)

The core nonlinearity: Iout = Ix²/Iu.

**Topology (validated after two failed variants — the trap and the fix):**
- Left: two diode-connected NPNs **stacked in series** (Q2 on Q1), ONE current
  source Ix into the top. The same Ix flows through both junctions — this is
  the invariant earlier attempts violated by driving each junction separately.
- Right: Q3 diode-connected at Iu; Q4 with base at the stack top, emitter on
  Q3. Loop KVL: 2·Vbe(Ix) = Vbe(Iu) + Vbe(Iout) ⇒ **Iout = Ix²/Iu.**
- Correction mirror: Q4's emitter current corrupts Q3's operating point; a
  PNP→NPN mirror chain copies Iout and pulls it back out of the Q3 node.
- **Beta-helper** on the PNP mirror (its 3 outputs otherwise lose 4/β ≈ 4%).

**Measured:** quadratic law holds 0.25–2 µA with **1–2% systematic error**
(finite β + Early). Mismatch mapping is *exact*: with device Is mismatch,
Iout = (Is₃·Is₄)/(Is₁·Is₂)·Ix²/Iu — Is/area mismatch ≡ squarer gain error.

## P2 — Beta-helped current mirrors (inside P1)

PNP 2-output + helper; NPN 3-output. Error ~4/β² with helper. Standard cells;
on a real chip these become cascoded, common-centroid mirrors.

## P3 — Gm stage (state → current)

Ix = gm·V(x), gm = 1 µA/V. **Behavioral (VCCS) in current decks** — the one
primitive not yet at transistor level. On chip: resistively-degenerated diff
pair or a linearized OTA. Its gain error folds into the same knob as squarer
gain (validated by the mismatch MC), so its spec is simply: gain matching to
the mirror set, linearity over 0–2×I_u.

## P4 — Error node + integrator

KCL at the cap: C·dVx/dt = Ix + Iu − Isq = −I_u·(x² − x − 1).
One capacitor (100 pF at 1 µA scale → τ ≈ 100 µs; scale C/I to taste — the
fixed point is independent of both). Single real pole, no compensation needed.

## P5 — φ-cell: the closed loop  (`phi_cell_transistor.cir`)

P1+P2+P3+P4 in a loop. **Measured: settles to x = 1.6263** — φ + 0.51%
systematic — untrimmed, no clock, from arbitrary start. Flat after ~10τ.
The 0.5% is *bias*, not noise: it comes from finite-β and is correctable by
cascoding/trim; it is NOT fixed by lattice averaging (it's common-mode).

## P6 — Diffusive coupling

One resistor between neighboring state nodes. Coupling conductance vs loop
slope (√5·gm ≈ 2.2 µA/V): R = 100 kΩ gives ~4.5× loop slope — strong coupling,
cells co-settle to a common value that averages their parameter errors.

## P7 — Coupled lattice: mismatch averaging  (`phi_pair_mc.cir`, `phi_quad_mc.cir`)

Monte-Carlo at transistor level, 2% σ per knob (Q4 area, pull-mirror area,
Iu, Iun — independent per cell):

| N (cells) | mean x  | σ       | σ₁/σ_N | theory √N |
|-----------|---------|---------|--------|-----------|
| 1         | 1.632   | 0.0409  | 1.00   | 1.00      |
| 2         | 1.631   | 0.0259  | 1.56   | 1.41      |
| 4 (ring)  | 1.631   | 0.0208  | 1.97   | 2.00      |

**The √N law holds at transistor level.** Random mismatch averages out across
the coupled lattice; the mean stays put.

### Precision scaling (from measured σ₁ = 4.1%, 3σ criterion)

| target        | required N |
|---------------|-----------|
| 6-bit φ       | ~25       |
| 8-bit φ       | ~370      |
| 10-bit φ      | ~5,900    |

N grows as 4ᵇⁱᵗˢ — the lattice buys real precision cheaply up to ~8 bits,
then the digital branchless core takes over. This is the quantitative version
of why the substrate is many coupled nodes: **per-cell φ is coarse (4-bit);
lattice φ is engineerable.**

---

## Chip architecture this implies

```
        ┌────────┐   Rc   ┌────────┐   Rc   ┌────────┐
   ...──┤ φ-cell ├────────┤ φ-cell ├────────┤ φ-cell ├──...
        └───┬────┘        └───┬────┘        └───┬────┘
            │ x_i (analog φ, local, coarse)     │
            └────────── lattice x̄ ≈ φ ± σ₁/√N ──┘
```

- The lattice IS the φ-reference; any node reads x̄ through its neighbors.
- No clock, no stored constant, no startup sequence: power-on → relax to φ.
- This is structurally the analog twin of phi_pool: local coarse dynamics,
  global emergent precision — and the coupling resistor network is the analog
  seat of the Kuramoto term.

## Remaining work before tapeout track

1. **Gm stage at transistor level** (P3) — the only behavioral element left.
2. **Real PDK models** — these runs use ideal-β BJTs; port to subthreshold
   MOS (translinear law holds in weak inversion) or a bipolar/BiCMOS PDK,
   re-run the MC with foundry mismatch data (Pelgrom coefficients).
3. **Systematic-bias design-out** — the +0.5% cell bias needs cascodes or a
   one-point trim; averaging cannot remove it.
4. **Temp/supply corners** — translinear ratios are ratiometric (Vt cancels
   around the loop) so first-order temp-flat, but verify with real models.
5. **Oscillator variant** — cross-couple two cells with a phase-shifting
   element to get the φ-oscillator (Kuramoto seed) rather than a DC reference.

## File index

| file                          | contents                                   |
|-------------------------------|--------------------------------------------|
| phi_squarer_translinear.cir   | P1 standalone, swept, validated            |
| phi_cell_transistor.cir       | P5 closed loop → settles 1.6263            |
| phi_pair_mc.cir               | N=1 vs N=2 Monte-Carlo (80 runs)           |
| phi_quad_mc.cir               | N=1 vs N=4 ring Monte-Carlo (60 runs)      |
| phi_loop.cir / phi_montecarlo.cir | earlier behavioral loop + MC           |
| phi_analog_cell.md            | ODE derivation, stability, sensitivity     |
