# KiCad legacy netlist (.net) generator for PHI-STRAND-1 card and PHI-BUS-8 backplane.
# Explicit pin-level connection tables; self-validating (no pin used twice,
# all supply pins connected, net accounting printed).
FP = {
 'SOIC16':'Package_SO:SOIC-16_3.9x9.9mm_P1.27mm',
 'SOIC8' :'Package_SO:SOIC-8_3.9x4.9mm_P1.27mm',
 'SOT23' :'Package_TO_SOT_SMD:SOT-23',
 'SOD323':'Diode_SMD:D_SOD-323',
 'R0805' :'Resistor_SMD:R_0805_2012Metric',
 'C0805' :'Capacitor_SMD:C_0805_2012Metric',
 'HDR2x8':'Connector_PinHeader_2.54mm:PinHeader_2x08_P2.54mm_Vertical',
 'HDR1x3':'Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical',
 'TRS'   :'Connector_Audio:Jack_3.5mm_PJ320A_Horizontal',
 'TERM3' :'TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-3_1x03_P5.00mm_Horizontal',
 'TP'    :'TestPoint:TestPoint_Pad_1.5x1.5mm',
 'JP2'   :'Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical',
}
def emit(name, comps, nets, fname):
    # validate
    used={}
    for nn,pins in nets.items():
        for ref,pin in pins:
            key=(ref,str(pin))
            assert key not in used, f"{name}: pin {key} in nets {used.get(key)} and {nn}"
            used[key]=nn
            assert ref in comps, f"{name}: {ref} not declared"
    for ref,(val,fp,mpn) in comps.items():
        if ref.startswith('U'):
            pass
    s=['(export (version D)',
       f' (design (source "{name}") (tool "phi-gen"))',' (components']
    for ref,(val,fp,mpn) in sorted(comps.items()):
        s.append(f'  (comp (ref {ref}) (value "{val}") (footprint {FP[fp]}) (fields (field (name MPN) "{mpn}")))')
    s.append(' )'); s.append(' (nets')
    for i,(nn,pins) in enumerate(sorted(nets.items()),1):
        row=f'  (net (code {i}) (name "{nn}")'
        for ref,pin in pins: row+=f' (node (ref {ref}) (pin {pin}))'
        s.append(row+')')
    s.append(' ))')
    open(fname,'w').write('\n'.join(s))
    print(f"{name}: {len(comps)} components, {len(nets)} nets, {len(used)} pins -> {fname}")

# ============ PHI-STRAND-1 card ============
C={}; N={}
def comp(ref,val,fp,mpn): C[ref]=(val,fp,mpn)
def net(name,*pins):
    N.setdefault(name,[]).extend(pins)
comp('U1','LM13700 gyrator','SOIC16','LM13700M/NOPB')
comp('U2','LM13700 injector','SOIC16','LM13700M/NOPB')
comp('J1','card edge','HDR2x8','generic 2x8 0.1in')
for r,v in [('R1','470k'),('R2','470k'),('R3','110k'),('R4','110k'),
            ('R5','300k'),('R6','10k'),('R7','300k'),('R8','10k'),
            ('R9','10k'),('R10','1k'),('R11','10k'),('R12','1k'),
            ('R13','7.5M'),('R14','7.5M'),('R15','1M'),('R16','10M'),
            ('R17','10M'),('R18','1M'),('R19','10M'),('R20','10M'),
            ('R21','2M'),('R22','1.5M'),('R23','300k'),('R24','100k')]:
    comp(r,v,'R0805','Yageo RC0805FR-07'+v.replace('.','R'))
for c,v in [('C1','Cn-A1 see table'),('C2','Cn-A2 see table'),
            ('C3','Cn-B1 see table'),('C4','Cn-B2 see table'),
            ('C5','100n'),('C6','100n'),('C7','100n'),('C8','100n')]:
    comp(c,v,'C0805','C0G per strand table' if c in ('C1','C2','C3','C4') else 'X7R 100n 50V')
comp('D1','1N4148WS','SOD323','1N4148WS'); comp('D2','1N4148WS','SOD323','1N4148WS')
comp('JP1','probe enable','JP2','jumper')
comp('TP1','X1','TP','testpoint'); comp('TP2','X2','TP','testpoint'); comp('TP3','GND','TP','testpoint')
# phi-cells: A on X1 (Q1-Q15), B on X2 (Q16-Q30). NPN BC847B, PNP BC857B. SOT-23: 1=B 2=E 3=C
npnA=['QG','Q1','Q2','Q3','Q4','QN1','QN2','QN3']; pnpA=['QM1','QM2','QM3','QMH','QP1','QP2','QH']
refmap={}
idx=1
for cell in ('A','B'):
    for nm in npnA:
        refmap[nm+cell]=f'Q{idx}'; comp(f'Q{idx}','BC847B','SOT23','BC847B,215'); idx+=1
    for nm in pnpA:
        refmap[nm+cell]=f'Q{idx}'; comp(f'Q{idx}','BC857B','SOT23','BC857B,215'); idx+=1
def cellnets(cell, X):
    m=lambda nm: refmap[nm+cell]
    g1,ge,n1,n2,n3,n4,nb,n6=[f'{p}{cell}' for p in ('G1','GE','N1','N2','N3','N4','NB','N6')]
    RE,Riu,Riun = (('R15','R16','R17') if cell=='A' else ('R18','R19','R20'))
    net(g1,(m('QG'),3),(m('QM1'),3),(m('QMH'),1))
    net(ge,(m('QG'),2),(RE,1)); net('GND',(RE,2))
    net(X,(m('QG'),1),(m('QM3'),3),(m('QN3'),3),(Riun,2))
    net('MB'+cell,(m('QM1'),1),(m('QM2'),1),(m('QM3'),1),(m('QMH'),2))
    net('+12V',(m('QM1'),2),(m('QM2'),2),(m('QM3'),2),(Riu,1),(Riun,1))
    net('GND',(m('QMH'),3))
    net(n1,(m('Q1'),3),(m('Q1'),1),(m('Q2'),2)); net('GND',(m('Q1'),2))
    net(n2,(m('Q2'),3),(m('Q2'),1),(m('QM2'),3),(m('Q4'),1))
    net(n3,(m('Q3'),3),(m('Q3'),1),(Riu,2),(m('Q4'),2),(m('QN2'),3)); net('GND',(m('Q3'),2))
    net(n4,(m('Q4'),3),(m('QP1'),3),(m('QH'),1))
    net(nb,(m('QP1'),1),(m('QP2'),1),(m('QH'),2))
    net('+12V',(m('QP1'),2),(m('QP2'),2)); net('GND',(m('QH'),3))
    net(n6,(m('QP2'),3),(m('QN1'),3),(m('QN1'),1),(m('QN2'),1),(m('QN3'),1))
    net('GND',(m('QN1'),2),(m('QN2'),2),(m('QN3'),2))
cellnets('A','X1'); cellnets('B','X2')
# state caps + clamps
net('X1',('C1',1),('C2',1),('D1',1),('TP1',1))
net('X2',('C3',1),('C4',1),('D2',1),('TP2',1))
net('GND',('C1',2),('C2',2),('C3',2),('C4',2),('D1',2),('D2',2),('TP3',1))
# U1 gyrator: A: out5->X1, in+3 <- X2 divider (R5/R6 to XR), in-4 -> XR
net('X2',('R5',1)); net('GYA',('R5',2),('U1',3),('R6',1)); net('XR',('R6',2),('U1',4))
net('X1',('U1',5))
net('X1',('R7',1)); net('GYB',('R7',2),('U1',13),('R8',1)); net('XR',('R8',2),('U1',14))
net('X2',('U1',12))
net('+12V',('U1',11),('R1',1),('R2',1),('R3',1),('R4',1))
net('IAB_A1',('R1',2),('U1',1)); net('IAB_B1',('R2',2),('U1',16))
net('DB_A1',('R3',2),('U1',2)); net('DB_B1',('R4',2),('U1',15))
net('-12V',('U1',6)); net('GND',('U1',7),('U1',10))
# U2 injector: A: out5->X1, in+3 <- X1 divider R9/R10 to XR, in-4->XR; Iabc from MODE via R13/R14
net('X1',('R9',1)); net('INA',('R9',2),('U2',3),('R10',1)); net('XR',('R10',2),('U2',4))
net('X1',('U2',5))
net('X2',('R11',1)); net('INB',('R11',2),('U2',14),('R12',1)); net('XR',('R12',2),('U2',13))
net('X2',('U2',12))
net('MODE',('R13',1),('R14',1)); net('IAB_A2',('R13',2),('U2',1)); net('IAB_B2',('R14',2),('U2',16))
net('+12V',('U2',11)); net('-12V',('U2',6)); net('GND',('U2',7),('U2',10))
# pilot / probe / sum / chain
net('PILOT',('R22',1)); net('X1',('R22',2))
net('PROBE',('JP1',1)); net('PRB2',('JP1',2),('R23',1)); net('X1',('R23',2))
net('X1',('R24',1)); net('SUM',('R24',2))
net('X1',('R21',1)); net('X1R',('R21',2))
# decoupling
net('+12V',('C5',1),('C7',1)); net('-12V',('C6',1),('C8',1)); net('GND',('C5',2),('C6',2),('C7',2),('C8',2))
# edge connector
for pin,nn in [(1,'+12V'),(2,'GND'),(3,'-12V'),(4,'GND'),(5,'XR'),(6,'MODE'),(7,'PILOT'),(8,'PROBE'),
               (9,'X1'),(10,'X1R'),(11,'SUM'),(12,'GND'),(13,'GND'),(14,'GND'),(15,'GND'),(16,'GND')]:
    net(nn,('J1',pin))
emit('PHI-STRAND-1',C,N,'/tmp/phi_strand_card.net')

# ============ PHI-BUS-8 backplane ============
C={}; N={}
comp('U3','TL072 xr-buf + sum','SOIC8','TL072CDR')
# shared reference phi-cell (same topology, node = XRC)
idx=1
refmap={}
for nm in npnA: refmap[nm+'R']=f'Q{idx}'; comp(f'Q{idx}','BC847B','SOT23','BC847B,215'); idx+=1
for nm in pnpA: refmap[nm+'R']=f'Q{idx}'; comp(f'Q{idx}','BC857B','SOT23','BC857B,215'); idx+=1
for r,v in [('R1','1M'),('R2','10M'),('R3','10M'),('R4','20k'),('R5','1k'),
            ('R6','1M'),('R7','1M'),('R8','150k'),('R9','91k')]:
    comp(r,v,'R0805','Yageo RC0805FR-07'+v.replace('.','R'))
for c,v in [('C1','10n C0G'),('C2','10u'),('C3','10u'),('C4','10u'),
            ('C5','100n'),('C6','100n')]:
    comp(c,v,'C0805','per value')
comp('D1','1N4148WS','SOD323','1N4148WS')
for j in range(1,9): comp(f'J{j}','slot','HDR2x8','2x8 receptacle')
comp('J9','PILOT jack','TRS','PJ-320A'); comp('J10','PROBE jack','TRS','PJ-320A'); comp('J11','OUT jack','TRS','PJ-320A')
comp('J12','power','TERM3','MKDS 1.5/3'); comp('JP2','mode sel','HDR1x3','header')
# reference cell nets on node XRC (reuse cellnets pattern inline)
m=lambda nm: refmap[nm+'R']
RE,Riu,Riun='R1','R2','R3'
net('G1R',(m('QG'),3),(m('QM1'),3),(m('QMH'),1))
net('GER',(m('QG'),2),(RE,1)); net('GND',(RE,2))
net('XRC',(m('QG'),1),(m('QM3'),3),(m('QN3'),3),(Riun,2),('C1',1),('D1',1),('U3',3))
net('MBR',(m('QM1'),1),(m('QM2'),1),(m('QM3'),1),(m('QMH'),2))
net('+12V',(m('QM1'),2),(m('QM2'),2),(m('QM3'),2),(Riu,1),(Riun,1))
net('GND',(m('QMH'),3),('C1',2),('D1',2))
net('N1R',(m('Q1'),3),(m('Q1'),1),(m('Q2'),2)); net('GND',(m('Q1'),2))
net('N2R',(m('Q2'),3),(m('Q2'),1),(m('QM2'),3),(m('Q4'),1))
net('N3R',(m('Q3'),3),(m('Q3'),1),(Riu,2),(m('Q4'),2),(m('QN2'),3)); net('GND',(m('Q3'),2))
net('N4R',(m('Q4'),3),(m('QP1'),3),(m('QH'),1))
net('NBR',(m('QP1'),1),(m('QP2'),1),(m('QH'),2))
net('+12V',(m('QP1'),2),(m('QP2'),2)); net('GND',(m('QH'),3))
net('N6R',(m('QP2'),3),(m('QN1'),3),(m('QN1'),1),(m('QN2'),1),(m('QN3'),1))
net('GND',(m('QN1'),2),(m('QN2'),2),(m('QN3'),2))
# U3A: XR buffer (voltage follower): in+3=XRC(done), in-2 tied to out1
net('XR',('U3',1),('U3',2))
# U3B: summing inverting amp: in-6 = SUM bus, feedback R4 to out7; in+5 GND
net('SUM',('U3',6),('R4',1)); net('OUTA',('R4',2),('U3',7),('R5',1))
net('GND',('U3',5))
net('OUTJ',('R5',2),('C2',1))
net('+12V',('U3',8),('C5',1)); net('-12V',('U3',4),('C6',1)); net('GND',('C5',2),('C6',2))
# jacks: pilot in -> C3 -> PILOT bus + R6 leak; probe -> C4 -> PROBE + R7
net('PILOTJ',('J9',2),); net('PILOTJ',('C3',1))
net('PILOT',('C3',2),('R6',1)); net('GND',('R6',2),('J9',1))
net('PROBEJ',('J10',2),('C4',1)); net('PROBE',('C4',2),('R7',1)); net('GND',('R7',2),('J10',1))
net('OUTT',('C2',2),('J11',2)); net('GND',('J11',1))
# mode: JP2 pin1=+12(write), pin2=MODE bus, pin3=read divider R8/R9
net('+12V',('JP2',1),('R8',1)); net('MODE',('JP2',2)); net('RDV',('JP2',3),('R8',2),('R9',1)); net('-12V',('R9',2))
# power terminal
net('+12V',('J12',1)); net('GND',('J12',2)); net('-12V',('J12',3))
# slots: distribute rails; chain X1R(n)->X1L(n+1) i.e. J{n}.10 -> J{n+1}.9
for j in range(1,9):
    for pin,nn in [(1,'+12V'),(2,'GND'),(3,'-12V'),(4,'GND'),(5,'XR'),(6,'MODE'),(7,'PILOT'),(8,'PROBE'),
                   (11,'SUM'),(12,'GND'),(13,'GND'),(14,'GND'),(15,'GND'),(16,'GND')]:
        net(nn,(f'J{j}',pin))
for j in range(1,8):
    net(f'CH{j}',(f'J{j}',10),(f'J{j+1}',9))
net('NC_J1_9',('J1',9)); net('NC_J8_10',('J8',10))
emit('PHI-BUS-8',C,N,'/tmp/phi_backplane.net')
