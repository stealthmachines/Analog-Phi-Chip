# PHI-STRAND-1 / PHI-BUS-8 — PCB Fabrication Package

## What is in this package and who takes what

| deliverable | file | consumed by |
|---|---|---|
| Netlist, strand card | `phi_strand_card.net` | KiCad (Import Netlist) / layout service |
| Netlist, backplane | `phi_backplane.net` | KiCad / layout service |
| BOM, strand card | `BOM_phi_strand_card.csv` | assembly house / self-populate |
| BOM, backplane | `BOM_phi_backplane.csv` | assembly house / self-populate |
| Fab parameters | this document, §Fab order | fab order form (JLCPCB/PCBWay/OSHPark) |
| Per-strand cap table | this document, §Strand variants | assembly variants |
| Bring-up procedure | this document, §Bring-up | you |

**Honest status of the Gerber step:** a bare-board fab strictly requires
Gerbers, which require a layout pass — importing these netlists into KiCad,
placing, and routing (one careful session for the card, one easy session for
the backplane), or handing this exact package to a layout service (PCBWay
and JLCPCB both offer this; any freelance KiCad layout engineer takes
netlist+BOM+this spec as the complete input). The netlists are pin-level
validated (205 / 225 pin assignments, zero collisions, all supply pins
connected); the layout is the one step that needs human eyes on a ratsnest,
and no reputable flow skips that for a sensitive analog board.

## Fab order parameters (both boards)

- Layers: **2**
- Material: FR-4, Tg ≥ 130
- Thickness: 1.6 mm
- Copper: 1 oz outer
- Finish: HASL lead-free (ENIG optional; nothing here needs it)
- Solder mask: any; silkscreen: white
- Min track/space used: **8/8 mil** (design is µA-level audio-band analog —
  nothing tight; any fab's cheapest class passes)
- Min drill: 0.3 mm
- Board sizes: strand card **50 × 80 mm**; backplane **100 × 160 mm**
- Panelization: order the strand card as a **panel of 8** (V-score) — one
  panel = one complete array
- Qty: 1 panel + 1 backplane (plus spares as desired)
- No impedance control, no blind/buried vias, no castellation

## Layout guidance (for the KiCad session or layout service)

- Ground pour both sides, stitched; **star the XR net** — route XR as its
  own trace from the edge connector to all divider references; do not pour
  it into GND.
- Keep the two state nodes X1, X2 compact: state caps (C1–C4), clamps
  (D1, D2), and OTA outputs within ~15 mm; these are the only
  sensitive nets. 10 MΩ bias resistors: guard with grounded silk-free
  pour gap or route away from flux-prone areas; clean boards after
  hand-assembly (10 MΩ nodes hate flux residue).
- The 30 SOT-23 transistors are two identical cell blocks — lay out one
  cell, duplicate. Keep each cell's translinear quad (Q2/Q3/Q4/Q5
  positions) adjacent and same-orientation for thermal matching.
- Frequencies are 0.5–2.6 kHz at µA currents: no length matching, no
  controlled impedance, no thermal concerns. This is a forgiving board
  everywhere except leakage at the 10 MΩ nodes.
- Backplane: slots in a row, chain nets J(n).10→J(n+1).9 are short
  neighbor hops. Verify the PJ-320A jack footprint pin map against the
  chosen library part (tip/sleeve vary by vendor).

## Strand variants (assembly): state-cap table

Fab identical cards; populate C1‖C2 (= C3‖C4) per slot position:

| slot n | Cₙ target | populate (E24, C0G) | error | fₙ |
|---|---|---|---|---|
| 0 | 10.000 nF | 10n + DNP | 0.00% | 477.5 Hz |
| 1 | 7.862 nF | 7.5n + 360p | 0.02% | 607.3 Hz |
| 2 | 6.180 nF | 5.1n + 1.1n | 0.32% | 772.6 Hz |
| 3 | 4.859 nF | 4.3n + 560p | 0.03% | 982.7 Hz |
| 4 | 3.820 nF | 3n + 820p | 0.01% | 1250.0 Hz |
| 5 | 3.003 nF | 3n + DNP | 0.09% | 1590.0 Hz |
| 6 | 2.361 nF | 2.2n + 160p | 0.03% | 2022.6 Hz |
| 7 | 1.856 nF | 1.3n + 560p | 0.22% | 2572.8 Hz |

JP1 (probe jumper): install on the slot-0 card only.

## Electrical summary (traceability to the validated decks)

Every value maps to a measured simulation quantity:
gyrator k = 30 µ℧ (Iabc 47 µA, 30:1 dividers, linear ±0.9 V) — sets
fₙ = k/2πCₙ; injector = LM13700 native tanh, small-signal 5.5 µ℧ at
Iabc 3 µA with 11:1 divider (sim: 5.6 µ℧/1.867 V⁻¹); MODE rail = the
write/read switch (Iabc 3 µA / 1 µA — P10's two-mode result); Rc = 2 MΩ
(validated coupling); clamps + near-equilibrium power-up = rule 3;
C-ladder = rule 1; per-cell matched translinear quad with lattice
√N mismatch averaging = P7.

## Bring-up (mirrors the validated sequence)

1. Backplane alone: ±12 V, verify XR ≈ 1.4–2.2 V DC at TP/U3.1.
2. One card, slot 0, MODE=WRITE: X1/X2 oscillate near 477 Hz; check
   amplitude ≈ 0.5–1 V and clean quadrature (scope XY = circle).
3. All 8 cards: sound-card FFT on SUM out — 8 lines; verify adjacent
   ratios ≈ 1.272 (√φ) and alternate ratios ≈ 1.618 (φ).
4. MODE=READ + pilot comb (8 tones at bin-exact fₙ from sound-card ch1):
   lines pin to comb; floors drop.
5. Probe two-tone on ch2 → the (1+z)ⁿ ladder test (expected: product-law
   agreement, per P10's 1–3% result).
6. Genome write/read per P11 (bursts in WRITE, demod vs reference capture).

## MPN substitutions (all safe)

BC847B/BC857B → BC847C/BC857C, MMBT3904/3906 (re-check pinout: SOT-23
1=B 2=E 3=C holds for BC847/57; MMBT3904 is 1=B 2=E 3=C as well);
LM13700M → LM13700N (DIP-16, change footprint); TL072 → TL082, OPA2137;
1N4148WS → BAS316. Do not substitute the C0G/NP0 dielectric on C1–C4.
