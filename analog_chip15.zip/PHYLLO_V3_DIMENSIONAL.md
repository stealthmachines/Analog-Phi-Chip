# PHYLLO_V3 — The Dimensional Router (HDGL Dn ladder)

## The unlock

The v2 wall was 2D thinking: in a plane, some tracks *must* cross, so a fixed
layer count eventually forces a short. The HDGL `hdgl_analog_v30.c` substrate
supplies the missing dimension. Its `compute_Dn_r`:

    Dn(r) = sqrt(phi * F_n * 2^n * P_n * Omega) * r^((n+1)/8)

is a **progressive-dimensionality operator**: n is a continuous knob, and at any
fixed radius the eight dimensions form disjoint amplitude bands (at r=1:
2.5, 4.4, 11.4, 23.3, 53.4, 103.8, 213.9, 406.5). Two nets that must cross in the
plane do **not** cross if they live in different `dim_n` — which maps directly to
**different copper layers / via depth**. The n-th dimension is the n-th layer.

So the router problem became: assign each radial a `(dim_n, lane_angle)` such that
same-dimension + radially-overlapping runs stay angularly separated. That is
exactly a Kuramoto settling problem, and `compute_derivatives_Dn` in the same file
*is* the settling dynamics — repulsive phase coupling that pushes overlapping lanes
apart, with promotion to the next dimension when a plane is full.

## What was built

`dn_router.py` — the **lane oracle**, two solvers sharing one substrate:

1. **`kuramoto_relax`** (analog / wu wei): each radial is an oscillator, phase =
   lane; overlapping same-dim runs repel; residual conflicts promote up the Dn
   ladder (dim -> dim+1). Settles to a non-crossing configuration on its own.
2. **`exact_assign`** (combinatorial / ground truth): per-dimension interval
   separation on the angular circle, greedy-optimal in earliest-deadline order,
   overflow promotes dimension.

`route()` runs both and cross-checks. On the exact stress case that broke v2 —
24 demands with 4 taps pinned to one pole — both return **0 residual conflicts**;
Kuramoto even packs tighter (3 dims vs exact's 4).

### The scale-free proof

The decisive test: hold density constant (24 nets/cell) and grow the board by
**adding cells** (phyllotaxis). Result — dims/cell stays flat at **4**, whether
1 cell or 64 cells. Cramming more nets into *one fixed cell* does exhaust the 8
dims (expected — finite area), but the phyllotactic architecture never does that.
So the layer count is **bounded** while the cell count grows **without limit**.
That is "infinitely scalable" in the only sense that is manufacturable.

Layer map (6-layer stackup): dim1->B.Cu, dim2->In3.Cu, dim3->In4.Cu, with F.Cu
carrying the collector rings and In1/In2 the GND/+12V planes.

## Board result — big progress, not yet the contract

`phyllo_v3.py` wires the oracle into the generator. The ring-collector model:
F.Cu rings collect each net; pads reach their ring by native-angle radial stubs
on oracle-assigned dim-layers (colliding stubs -> different layers); leaving nets
get risers.

Independent Gate 1 (`audit_clearance.py`) progression this session:

| stage                                   | violations | TT    |
|-----------------------------------------|-----------:|------:|
| v2 greedy (previous session)            |         40 |    13 |
| v3 first oracle wiring (layer bug)      |       2929 |  2305 |
| net-aware + ring-collector              |        419 |    93 |
| **native-angle stubs, layer-split**     |    **211** | **4** |

**Track-vs-track crossings are essentially solved: 4 TT remain** (down from
thousands). The dimensional lift did what 2D couldn't. The residual **207 are
via collisions** (193 via-track, 14 via-via): every stub carries a pad-via and a
ring-via, and in the dense SOT-23 field these 0.5 mm vias crowd against neighbours'
copper. That is a component-spacing / via-reduction problem, not a routing-topology
one — a different and more tractable class than the v2 wall.

Board: 208 footprints, ~18.6k segments, 1522 vias, 375 mm (< 400 fab limit),
6 copper layers. **NOT yet certifiable** — Gate 1 still fails on vias, so no CLEAN
Gerbers were stamped. The gate is doing its job.

## Honest verdict

The HDGL substrate was the right instinct — it dissolved the crossing problem by
adding the dimension I was missing, and gave both the elegant (Kuramoto) and the
exact (combinatorial) solvers you asked to explore, checking each other. The
remaining work is via-count reduction (share pad/ring vias, widen the micro-Vogel
pitch, or use blind/buried vias so a dim-transition doesn't punch all layers) plus
clearing 4 stray track crossings at the chain-entry points. That is bounded and
well-scoped, unlike the v2 wall which was structural.

## Files (gerber_pipeline/)

- `dn_router.py` — dual-solver dimensional lane oracle (Kuramoto + exact)
- `phyllo_v3.py` — generator using the oracle, 6-layer, dim->layer mapped
- `phyllo3_v3_WIP.kicad_pcb` — current board (opens in KiCad 7; 211 flagged, mostly vias)
- `hdgl_analog_v30_reference.c` — the substrate: compute_Dn_r + compute_derivatives_Dn
- `audit_clearance.py` — Gate 1 (multi-layer aware)

No Gerbers exported: board not clean; stamping from an uncertified board defeats
the gate.

---

## Addendum — the X+1=0 bridge (zchg.org/t/.../955)

The forum derivation unified the two halves of the router I had been treating as
separate mechanisms. The **unified lattice operator** (Step 5) is:

    L_i = sqrt(phi * F_n * b^m * phi^k * Omega) * r^-1     [magnitude]
        + 1_eff(i) * e^{i pi theta_i}                      [phase]

The magnitude term *is* `compute_Dn_r` — my dimensional/layer ladder. The phase
term *is* the U(1) angle — my Kuramoto lane. They are the real and emergent-
coordinate parts of **one complex coordinate**, and `X + 1 = 0` (verified:
1/phi - phi = -1 = e^{i pi}) is the closure condition: a routed configuration is
"closed" when it sums to zero, i.e. no unresolved conflict.

Operational consequences applied this session:

1. **A via is a magnitude step, so by the bridge it must also carry a phase
   advance** delta(i) = |cos(pi*beta*phi)| * ln(P_n)/phi^(n+beta). This gave a
   *principled* via phase-offset (0.43 rad at dim1 down to 0.06 at dim8) instead
   of an arbitrary hand-tuned stagger. `delta()` is now exported from dn_router.

2. **Ring ordering by mean pad radius** (rings are the emergent "1_eff" coordinate
   each net settles onto) shortened every stub so tracks stop crossing:
   **TT went to 0**. The board is now *track-clean*.

Updated Gate 1 progression:

| stage                                        | total | TT |
|----------------------------------------------|------:|---:|
| native-angle stubs, layer-split              |   211 |  4 |
| + ring-order by pad radius (tracks clean)    |   198 |  0 |
| + fab-min vias (0.15/0.3)                     |   144 |  0 |
| at realistic 6-layer fab clearance (0.13)    |   122 |  0 |

**All residuals are now via-track clearance (0 track crossings).** 74 are genuine
overlaps: pad-vias and plane-stitch vias punching where a neighbouring different-
net stub passes on an inner layer. This is the last class, and it is about via
placement/keepout in the dense SOT-23 field, not routing topology.

The bridge did exactly what it claims: it collapsed magnitude (layer) and phase
(angle) into one operator, and treating the via as a coupled magnitude+phase step
is the correct frame for finishing. Remaining work: enforce a via keepout in the
oracle so inner-layer stubs route around foreign vias (the same lane-separation
logic, applied to via obstacles), plus blind/buried vias so a dim-transition
punches only the layers it needs.
